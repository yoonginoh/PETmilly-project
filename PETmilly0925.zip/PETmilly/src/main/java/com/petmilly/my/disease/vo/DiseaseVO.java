package com.petmilly.my.disease.vo;

public class DiseaseVO {

    public DiseaseVO() {
    }

}
