package com.petmilly.my.disease.dao;

import org.apache.ibatis.annotations.Mapper;

import com.petmilly.my.member.vo.MemberVO;

@Mapper
public interface DiseaseDAO {

}
