package com.petmilly.my.disease.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.petmilly.my.member.dao.IMemberDAO;
import com.petmilly.my.member.vo.MemberVO;

@Service
public class DiseaseService {
	

	
}
